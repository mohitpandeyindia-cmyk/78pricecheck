// Automatically generated build metadata
window.APP_BUILD = {
  version: "0.1.0",
  build: "202607270059",
  commit: "4b039d1",
  branch: "main",
  buildTime: "2026-07-27T00:59:43.017Z",
  environment: "production",
  serviceWorkerEnabled: true
};
